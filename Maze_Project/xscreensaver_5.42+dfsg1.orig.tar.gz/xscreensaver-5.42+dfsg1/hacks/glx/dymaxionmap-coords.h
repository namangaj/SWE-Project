#ifndef __DYMAXIONMAP_COORDS_H__
#define __DYMAXIONMAP_COORDS_H__

void dymaxion_convert (double lng, double lat, double *x, double *y);

#endif /* __DYMAXIONMAP_COORDS_H__ */
